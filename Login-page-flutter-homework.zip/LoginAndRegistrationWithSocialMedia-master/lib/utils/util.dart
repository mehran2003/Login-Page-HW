import 'package:registration_login/utils/list_item.dart';

class Util {
  static const String name = "Registration and Login";
  static const String store = "Online Store\n For Everyone";
  static const String skip = "SKIP";
  static const String next = "NEXT";
  static const String gotIt = "GOT IT";
  static String userName ="";
  static String emailId ="";
  static String profilePic ="";
  static List<String> descriptionList = new List<String>();
  static List<String> mediaList = new List<String>();
  static List<ListItem> listItems = new List<ListItem>();

}
