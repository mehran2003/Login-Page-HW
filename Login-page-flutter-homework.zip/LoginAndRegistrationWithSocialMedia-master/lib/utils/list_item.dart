class ListItem {
String title;
String mediaImage;
ListItem(this.title, this.mediaImage);
}